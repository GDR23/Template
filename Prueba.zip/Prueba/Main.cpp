#include"Lista.h"
#include <conio.h>

int main() {
	Lista c;
	c.agregarElemento(5);
	c.agregarElemento(5);
	c.agregarElemento(6);
	c.agregarElemento(9);
	c.agregarElemento(1);
	c.agregarElemento(1);
	c.agregarElemento(1);
	c.agregarElemento(7);
	
	c.Funcion();

	_getch();
}
